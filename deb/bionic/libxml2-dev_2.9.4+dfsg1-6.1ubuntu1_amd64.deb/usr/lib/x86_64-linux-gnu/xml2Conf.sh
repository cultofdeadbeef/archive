#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/lib/x86_64-linux-gnu"
XML2_LIBS="-lxml2"
XML2_INCLUDEDIR="-I/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.4"

