#include "thanos_common.h"

FILE *output;
